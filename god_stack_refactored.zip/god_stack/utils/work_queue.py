"""
DistributedWorkQueue — SQLite-backed task queue with FIFO lease semantics.

BUG FIXED: Default db_path was hardcoded to /home/tangleroot013/god_stack/vaults/queue.db.
Replaced with a relative path under vaults/ that resolves from the working directory.

Schema: PENDING -> PROCESSING (lease) -> COMPLETED | PENDING (fail, requeues for retry)
BEGIN IMMEDIATE on lease_task serializes concurrent workers on the same DB file.
"""

from __future__ import annotations

import os
import sqlite3
from typing import Optional

_DEFAULT_DB_PATH = os.path.join("vaults", "queue.db")


class DistributedWorkQueue:
    def __init__(self, db_path: str = _DEFAULT_DB_PATH) -> None:
        self.db_path = db_path
        os.makedirs(os.path.dirname(os.path.abspath(self.db_path)), exist_ok=True)
        self._init_db()

    def _init_db(self) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS queue (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    url        TEXT    UNIQUE NOT NULL,
                    status     TEXT    NOT NULL DEFAULT 'PENDING',
                    claimed_by TEXT,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_queue_status ON queue(status, id)"
            )

    def enqueue(self, url: str) -> bool:
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("INSERT INTO queue (url) VALUES (?)", (url,))
            return True
        except sqlite3.IntegrityError:
            return False

    def enqueue_batch(self, urls: list[str]) -> int:
        inserted = 0
        with sqlite3.connect(self.db_path) as conn:
            for url in urls:
                try:
                    conn.execute("INSERT INTO queue (url) VALUES (?)", (url,))
                    inserted += 1
                except sqlite3.IntegrityError:
                    pass
        return inserted

    def lease_task(self, worker_id: str) -> Optional[tuple[int, str]]:
        with sqlite3.connect(self.db_path, timeout=30.0) as conn:
            conn.execute("BEGIN IMMEDIATE")
            cursor = conn.execute(
                "SELECT id, url FROM queue WHERE status = 'PENDING' ORDER BY id ASC LIMIT 1"
            )
            row = cursor.fetchone()
            if row:
                task_id, url = row
                conn.execute(
                    "UPDATE queue SET status = 'PROCESSING', claimed_by = ?, "
                    "updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                    (worker_id, task_id),
                )
                conn.commit()
                return task_id, url
            return None

    def complete_task(self, task_id: int) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "UPDATE queue SET status = 'COMPLETED', updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                (task_id,),
            )

    def fail_task(self, task_id: int) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "UPDATE queue SET status = 'PENDING', claimed_by = NULL, "
                "updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                (task_id,),
            )

    def depth(self) -> dict[str, int]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("SELECT status, COUNT(*) FROM queue GROUP BY status")
            return dict(cursor.fetchall())
