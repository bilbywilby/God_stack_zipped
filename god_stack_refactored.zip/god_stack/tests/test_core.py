"""
Core test suite — covers all fixed bugs and stable API contracts.

Run: python -m pytest tests/ -v
"""

from __future__ import annotations

import asyncio
import json
import os
import tempfile
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from url_sanitizer import UrlSanitizer
from parsers.html_parser import parse_html, MAX_PAYLOAD_BYTES
from frontier_manager import FrontierManager
from data_alchemist import DataAlchemist
from captcha_handler import CaptchaHandler
from courlan_router import CourlanRouter


# ---------------------------------------------------------------------------
# UrlSanitizer
# ---------------------------------------------------------------------------

class TestUrlSanitizer:
    def test_scheme_injection(self) -> None:
        assert UrlSanitizer.normalize("news.ycombinator.com") == "https://news.ycombinator.com"

    def test_protocol_relative(self) -> None:
        result = UrlSanitizer.normalize("//news.ycombinator.com/ask")
        assert result.startswith("https://")

    def test_tracker_stripping(self) -> None:
        url = "https://news.ycombinator.com/front?utm_source=twitter&id=123"
        result = UrlSanitizer.normalize(url)
        assert "utm_source" not in result
        assert "id=123" in result

    def test_query_param_sort_deterministic(self) -> None:
        a = UrlSanitizer.normalize("https://example.com?z=1&a=2")
        b = UrlSanitizer.normalize("https://example.com?a=2&z=1")
        assert a == b

    def test_fragment_stripped(self) -> None:
        result = UrlSanitizer.normalize("https://example.com/page#section")
        assert "#" not in result

    def test_trailing_slash_stripped(self) -> None:
        result = UrlSanitizer.normalize("https://example.com/path/")
        assert not result.endswith("/")

    def test_host_lowercased(self) -> None:
        result = UrlSanitizer.normalize("HTTPS://NEWS.YCOMBINATOR.COM/newest/")
        assert result == "https://news.ycombinator.com/newest"

    def test_empty_returns_empty(self) -> None:
        assert UrlSanitizer.normalize("") == ""
        assert UrlSanitizer.normalize(None) == ""  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# HTML Parser
# ---------------------------------------------------------------------------

class TestHtmlParser:
    def test_title_extracted(self) -> None:
        html = "<html><head><title>Hello World</title></head><body></body></html>"
        result = parse_html(html)
        assert result["title"] == "Hello World"

    def test_links_extracted(self) -> None:
        html = '<html><body><a href="https://example.com">link</a></body></html>'
        result = parse_html(html)
        assert "https://example.com" in result["links"]

    def test_javascript_links_excluded(self) -> None:
        html = '<html><body><a href="javascript:void(0)">bad</a></body></html>'
        result = parse_html(html)
        assert not any("javascript:" in l for l in result["links"])

    def test_oversized_payload_dropped(self) -> None:
        huge = "a" * (MAX_PAYLOAD_BYTES + 1)
        result = parse_html(huge)
        assert result["title"] == "Payload Threshold Abort"
        assert result["links"] == []

    def test_empty_html_safe(self) -> None:
        result = parse_html("")
        assert result["title"] is None
        assert result["links"] == []

    def test_links_deduplicated(self) -> None:
        html = (
            '<html><body>'
            '<a href="https://example.com">a</a>'
            '<a href="https://example.com">b</a>'
            '</body></html>'
        )
        result = parse_html(html)
        assert result["links"].count("https://example.com") == 1


# ---------------------------------------------------------------------------
# GodEngine — fixed: no singleton, inject instance, correct API surface
# ---------------------------------------------------------------------------

class TestGodEngine:
    @pytest.mark.asyncio
    async def test_initialize_sets_ready(self) -> None:
        from god_engine import GodEngine
        engine = GodEngine()
        assert not engine.initialized
        await engine.initialize()
        assert engine.initialized

    @pytest.mark.asyncio
    async def test_fetch_and_extract_returns_success(self) -> None:
        from god_engine import GodEngine
        engine = GodEngine()
        await engine.initialize()
        result = await engine.fetch_and_extract("https://example.com")
        assert result["status"] == "SUCCESS"
        assert "extracted_data" in result
        assert "links" in result["extracted_data"]

    @pytest.mark.asyncio
    async def test_raises_if_not_initialized(self) -> None:
        from god_engine import GodEngine
        engine = GodEngine()
        with pytest.raises(RuntimeError, match="initialize"):
            await engine.fetch_and_extract("https://example.com")

    @pytest.mark.asyncio
    async def test_shutdown_clears_ready(self) -> None:
        from god_engine import GodEngine
        engine = GodEngine()
        await engine.initialize()
        await engine.shutdown()
        assert not engine.initialized

    @pytest.mark.asyncio
    async def test_oversized_payload_aborted(self) -> None:
        from god_engine import GodEngine
        engine = GodEngine()
        await engine.initialize()
        huge_html = "x" * (MAX_PAYLOAD_BYTES + 1)
        result = await engine.fetch_and_extract("https://example.com", raw_html_content=huge_html)
        assert result["status"] == "ABORTED_CEILING_EXCEEDED"

    @pytest.mark.asyncio
    async def test_no_module_level_singleton(self) -> None:
        """Confirm the module-level GodEngineNode singleton was removed."""
        import god_engine
        assert not hasattr(god_engine, "GodEngineNode"), (
            "GodEngineNode singleton must not exist — causes dual-instance state split"
        )


# ---------------------------------------------------------------------------
# Orchestrator — fixed: process_target_array → fetch_and_extract, injected engine
# ---------------------------------------------------------------------------

class TestGodOrchestrator:
    @pytest.mark.asyncio
    async def test_execute_mission_calls_fetch_and_extract(self) -> None:
        from god_engine import GodEngine
        from orchestrator import GodOrchestrator

        engine = GodEngine()
        await engine.initialize()
        orch = GodOrchestrator(engine, use_proxies=False)
        await orch.initialize_matrix()

        result = await orch.execute_mission("https://news.ycombinator.com/")
        assert result["status"] == "SUCCESS"

    @pytest.mark.asyncio
    async def test_invalid_url_returns_error(self) -> None:
        from god_engine import GodEngine
        from orchestrator import GodOrchestrator

        engine = GodEngine()
        await engine.initialize()
        orch = GodOrchestrator(engine, use_proxies=False)
        await orch.initialize_matrix()

        result = await orch.execute_mission("")
        assert result["status"] == "ERROR"

    @pytest.mark.asyncio
    async def test_process_target_array_does_not_exist(self) -> None:
        """Confirm the broken method is not on GodEngine."""
        from god_engine import GodEngine
        engine = GodEngine()
        assert not hasattr(engine, "process_target_array"), (
            "process_target_array must not exist — it was the broken call site in orchestrator.py"
        )


# ---------------------------------------------------------------------------
# WorkerNode — fixed: CancelledError caught, not KeyboardInterrupt
# ---------------------------------------------------------------------------

class TestWorkerNode:
    @pytest.mark.asyncio
    async def test_cancellation_handled_cleanly(self) -> None:
        from god_engine import GodEngine
        from worker_node import WorkerNode

        engine = GodEngine()
        await engine.initialize()
        node = WorkerNode(engine, poll_interval=0.05)

        task = asyncio.create_task(node.run())
        await asyncio.sleep(0.1)
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        # Engine should be shut down in finally block
        assert not engine.initialized


# ---------------------------------------------------------------------------
# DaemonCore — fixed: avg_latency_ms is per-cycle, not per-item diluted
# ---------------------------------------------------------------------------

class TestDaemonCore:
    @pytest.mark.asyncio
    async def test_avg_latency_is_per_cycle(self) -> None:
        from daemon_core import RefinedOrchestrator
        with tempfile.TemporaryDirectory() as tmpdir:
            import daemon_core as dc
            orig_metrics = dc.METRICS_FILE
            orig_log = dc.LOG_FILE
            dc.METRICS_FILE = os.path.join(tmpdir, "metrics.json")
            dc.LOG_FILE = os.path.join(tmpdir, "daemon.log")
            try:
                orch = RefinedOrchestrator(interval_seconds=9999)
                await orch.invoke_pipeline_matrix()
                await orch.invoke_pipeline_matrix()

                with open(dc.METRICS_FILE) as f:
                    stats = json.load(f)

                # avg_latency_ms must be total_cycle_latency / cycle_count, not /tasks_total
                expected = stats["total_cycle_latency_ms"] / stats["cycle_count"]
                assert abs(stats["avg_latency_ms"] - expected) < 0.001, (
                    f"avg_latency_ms {stats['avg_latency_ms']} != "
                    f"per-cycle mean {expected}"
                )
            finally:
                dc.METRICS_FILE = orig_metrics
                dc.LOG_FILE = orig_log


# ---------------------------------------------------------------------------
# FrontierManager — fixed: no module-level singleton contamination between tests
# ---------------------------------------------------------------------------

class TestFrontierManager:
    def test_enqueue_batch_deduplicates(self) -> None:
        frontier = FrontierManager()
        with patch("frontier_manager.CourlanRouter.validate_and_clean", side_effect=lambda u: u):
            frontier.enqueue_batch(["https://a.com", "https://a.com"])
        assert len(frontier.seen_urls) == 1

    def test_dequeue_round_robins_domains(self) -> None:
        frontier = FrontierManager()
        with patch("frontier_manager.CourlanRouter.validate_and_clean", side_effect=lambda u: u):
            frontier.enqueue_batch([
                "https://a.com/1", "https://b.com/1", "https://a.com/2"
            ])
        first = frontier.dequeue()
        second = frontier.dequeue()
        assert first != second

    def test_flush_clears_state(self) -> None:
        frontier = FrontierManager()
        with patch("frontier_manager.CourlanRouter.validate_and_clean", side_effect=lambda u: u):
            frontier.enqueue_batch(["https://a.com"])
        frontier.flush()
        assert frontier.dequeue() == ""

    def test_stats_accurate(self) -> None:
        frontier = FrontierManager()
        with patch("frontier_manager.CourlanRouter.validate_and_clean", side_effect=lambda u: u):
            frontier.enqueue_batch(["https://a.com", "https://b.com"])
        stats = frontier.stats()
        assert stats["frontier.enqueue"] == 2
        assert stats["queue_depth"] == 2


# ---------------------------------------------------------------------------
# DataAlchemist
# ---------------------------------------------------------------------------

class TestDataAlchemist:
    def test_filters_empty_title(self) -> None:
        records = [{"title": "", "url": "https://a.com", "score": 5}]
        result = DataAlchemist.optimize_array_processing(records)
        assert result == []

    def test_filters_empty_url(self) -> None:
        records = [{"title": "Good Title", "url": "", "score": 5}]
        result = DataAlchemist.optimize_array_processing(records)
        assert result == []

    def test_valid_record_passes(self) -> None:
        records = [{"title": "HN Story", "url": "https://example.com", "score": 99}]
        result = DataAlchemist.optimize_array_processing(records)
        assert len(result) == 1
        assert result[0]["score"] == 99

    def test_non_dict_filtered(self) -> None:
        result = DataAlchemist.optimize_array_processing([None, "bad", 42])  # type: ignore
        assert result == []

    def test_empty_input(self) -> None:
        assert DataAlchemist.optimize_array_processing([]) == []


# ---------------------------------------------------------------------------
# CaptchaHandler
# ---------------------------------------------------------------------------

class TestCaptchaHandler:
    def test_detects_cloudflare(self) -> None:
        sentinel = CaptchaHandler()
        html = "<html><script src='https://challenges.cloudflare.com/turnstile/v0/api.js'></script></html>"
        assert sentinel.inspect_page_source(html) == "cloudflare"

    def test_detects_recaptcha(self) -> None:
        sentinel = CaptchaHandler()
        html = "<html><div class='g-recaptcha'></div></html>"
        assert sentinel.inspect_page_source(html) == "recaptcha"

    def test_clean_page(self) -> None:
        sentinel = CaptchaHandler()
        assert sentinel.inspect_page_source("<html><body>Normal page</body></html>") == "clean"

    def test_empty_input_clean(self) -> None:
        sentinel = CaptchaHandler()
        assert sentinel.inspect_page_source("") == "clean"


# ---------------------------------------------------------------------------
# Scavenger — fixed: walrus operator bug
# ---------------------------------------------------------------------------

class TestProxyScavenger:
    @pytest.mark.asyncio
    async def test_harvest_parses_ip_correctly(self) -> None:
        """Verify the walrus operator bug fix: IP validation uses direct .isdigit() check."""
        from scavenger import ProxyScavenger
        scavenger = ProxyScavenger()

        mock_html = """
        <table>
            <tr><th>IP</th><th>Port</th></tr>
            <tr><td>123.45.67.89</td><td>8080</td></tr>
            <tr><td>not-an-ip</td><td>9090</td></tr>
        </table>
        """

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.text = mock_html
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.get = AsyncMock(return_value=mock_response)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("scavenger.httpx.AsyncClient", return_value=mock_client):
            proxies = await scavenger.harvest_raw_list()

        assert "http://123.45.67.89:8080" in proxies
        assert not any("not-an-ip" in p for p in proxies)
