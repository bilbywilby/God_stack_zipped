"""
CourlanRouter — URL validation and crawler trap detection via courlan.

BUG FIXED: Original called logging.basicConfig() at module level, which stomps
the root logger config set by whichever module imports first. All parsers and
utilities in this codebase did the same, creating a logging.basicConfig() race.
All modules now use getLogger only; root config is set once in main entrypoints.

NOTE: log.info on every single URL validation call produces extreme log noise
at scale. Demoted to log.debug; rejections remain at WARNING.
"""

from __future__ import annotations

import logging
from urllib.parse import urlparse

import courlan

log = logging.getLogger("god_stack.courlan_router")


class CourlanRouter:
    """URL normalization, validation, and crawl-trap detection via courlan."""

    @staticmethod
    def validate_and_clean(url: str) -> str:
        if not url or not isinstance(url, str):
            return ""

        log.debug("Validating: %s", url)
        try:
            cleaned = courlan.clean_url(url)
            if not cleaned:
                return ""

            if not courlan.validate_url(cleaned):
                log.warning("Rejected by courlan validation: %s", url)
                return ""

            path_segments = [s for s in urlparse(cleaned).path.split("/") if s]
            if len(path_segments) > 5 and len(set(path_segments)) < len(path_segments) / 2:
                log.warning("Suspected recursive loop path — dropping: %s", cleaned)
                return ""

            return cleaned

        except Exception as exc:
            log.error("Courlan filter error for %r: %s", url, exc)
            return ""


if __name__ == "__main__":
    import logging as _logging
    _logging.basicConfig(level=_logging.DEBUG)
    test = "https://news.ycombinator.com/item?id=123&utm_source=feed#hash"
    print(CourlanRouter.validate_and_clean(test))
