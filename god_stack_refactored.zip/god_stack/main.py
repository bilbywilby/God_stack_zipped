"""
main.py — single canonical entrypoint for god_stack.

Replaces: run_stack.py, run_orchestrator.py, run_orchestrator_clean.py,
          run_unified_stack.py, run_all.py, run_stack_pipeline.py

Usage:
    python main.py daemon          # curses TUI dashboard (default)
    python main.py worker          # standalone task queue consumer
    python main.py batch           # one-shot batch sweep from config
    python main.py scrape <url>    # single URL extraction
"""

from __future__ import annotations

import asyncio
import json
import logging
import sys
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(name)s | %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("god_stack.main")


async def run_daemon() -> None:
    from daemon_core import RefinedOrchestrator
    orchestrator = RefinedOrchestrator(interval_seconds=300)
    await orchestrator.run_dashboard()


async def run_worker() -> None:
    from god_engine import GodEngine
    from worker_node import WorkerNode
    engine = GodEngine()
    await engine.initialize()
    node = WorkerNode(engine)
    await node.run()


async def run_batch() -> None:
    from batch_runner import BatchRunner
    config_path = Path("config/target_urls.json")
    if not config_path.exists():
        log.error("config/target_urls.json not found")
        sys.exit(1)
    targets: list[str] = json.loads(config_path.read_text())
    if not isinstance(targets, list):
        log.error("config/target_urls.json must be a JSON array of URL strings")
        sys.exit(1)
    await BatchRunner(targets).execute_grid_sweep()


async def run_scrape(url: str) -> None:
    from god_engine import GodEngine
    from orchestrator import GodOrchestrator
    engine = GodEngine()
    await engine.initialize()
    orch = GodOrchestrator(engine, use_proxies=False)
    await orch.initialize_matrix()
    result = await orch.execute_mission(url)
    print(json.dumps(result, indent=2, default=str))
    await engine.shutdown()


def main() -> None:
    args = sys.argv[1:]
    mode = args[0] if args else "daemon"

    if mode == "daemon":
        asyncio.run(run_daemon())
    elif mode == "worker":
        asyncio.run(run_worker())
    elif mode == "batch":
        asyncio.run(run_batch())
    elif mode == "scrape" and len(args) >= 2:
        asyncio.run(run_scrape(args[1]))
    else:
        print(__doc__)
        sys.exit(1)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
