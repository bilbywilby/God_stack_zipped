"""
DaemonCore — curses TUI dashboard over the async orchestration pipeline.

BUG FIXED: The original `launch_daemon(stdscr)` called `asyncio.run()` from
inside `curses.wrapper()`. This is safe when invoked as __main__ but fails
immediately with RuntimeError if this module is ever imported by an already-
running async caller (e.g. run_all.py, any test). The fix: `asyncio.run()` owns
the process lifecycle at top level; curses is initialized manually inside the
async entrypoint and torn down in a `finally` block, keeping the full event loop
alive for the entire dashboard lifetime.

BUG FIXED: `avg_latency_ms` is now computed as mean latency per cycle (duration
of each `invoke_pipeline_matrix` call), not cumulative tasks_total division which
produced a meaningless cross-run average diluted by item count.
"""

from __future__ import annotations

import asyncio
import curses
import json
import logging
import os
import time
from typing import Any

from parsers.dom_parser import HardenedDOMParser
from data_alchemist import DataAlchemist
from god_engine import GodEngine

LOG_FILE = "logs/daemon_orchestrator.log"
METRICS_FILE = "metrics/pipeline_stats.json"
os.makedirs("logs", exist_ok=True)
os.makedirs("metrics", exist_ok=True)

logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s | [%(levelname)s] %(message)s",
)
log = logging.getLogger("god_stack.daemon")

TARGETS = [
    "https://news.ycombinator.com/news",
    "https://news.ycombinator.com/newest",
    "https://news.ycombinator.com/best",
]


class MockElement:
    """Test fixture element matching HardenedDOMParser's expected interface."""
    def __init__(self, text: str, href: str, score_text: str | None = None) -> None:
        self.text = text
        self.href = href
        self.score_text = score_text

    def find(self, *args: Any, **kwargs: Any) -> "MockElement | None":
        if "class_" in kwargs:
            if kwargs["class_"] == "titleline" and self.text:
                return self
            if kwargs["class_"] == "score" and self.score_text:
                return self
        elif args and args[0] == "a" and self.text:
            return self
        return None

    def get_text(self, strip: bool = True) -> str:
        return self.score_text if self.score_text else self.text

    def get(self, attr: str, default: str = "") -> str:
        return self.href if attr == "href" else default


class RefinedOrchestrator:
    def __init__(self, interval_seconds: int = 300) -> None:
        self.interval = interval_seconds
        self.cycle_count = 0
        self.failures_encountered = 0
        self.last_execution_status = "INITIALIZED"

    def load_metrics(self) -> dict[str, Any]:
        try:
            if os.path.exists(METRICS_FILE):
                with open(METRICS_FILE) as f:
                    return json.load(f)
        except Exception:
            pass
        return {
            "tasks_total": 0,
            "tasks_successful": 0,
            "tasks_failed": 0,
            "last_latency_ms": 0.0,
            "avg_latency_ms": 0.0,
            "cycle_count": 0,
        }

    def load_latest_logs(self, max_lines: int = 10) -> list[str]:
        try:
            if os.path.exists(LOG_FILE):
                with open(LOG_FILE) as f:
                    return f.readlines()[-max_lines:]
        except Exception:
            pass
        return []

    async def invoke_pipeline_matrix(self) -> None:
        self.cycle_count += 1
        log.info("Cycle #%d starting", self.cycle_count)

        stats = self.load_metrics()

        raw_mocked_responses = [
            MockElement("Target Matrix Sync Complete", TARGETS[0], "90 points"),
            MockElement("Resilient Extraction Optimization", TARGETS[1], "142 points"),
            None,
            MockElement("   ", "Malformed Target URL", "0 points"),
        ]

        start_ts = time.perf_counter()
        extracted_nodes: list[dict] = []

        for element in raw_mocked_responses:
            try:
                node_data = HardenedDOMParser.extract_metrics_safely(element)
                extracted_nodes.append(node_data)
            except Exception as exc:
                self.failures_encountered += 1
                log.error("DOM extraction failure: %s", exc)

        purified_dataset = DataAlchemist.optimize_array_processing(extracted_nodes)
        cycle_duration_ms = (time.perf_counter() - start_ts) * 1000

        stats["tasks_total"] += len(raw_mocked_responses)
        stats["tasks_successful"] += len(purified_dataset)
        stats["tasks_failed"] += len(raw_mocked_responses) - len(purified_dataset)
        stats["last_latency_ms"] = cycle_duration_ms
        stats["cycle_count"] = self.cycle_count

        # BUG FIX: avg_latency_ms is per-cycle mean, not per-item diluted average.
        # Accumulate cycle latencies and divide by cycle count.
        stats["total_cycle_latency_ms"] = (
            stats.get("total_cycle_latency_ms", 0.0) + cycle_duration_ms
        )
        stats["avg_latency_ms"] = stats["total_cycle_latency_ms"] / self.cycle_count
        stats["last_updated"] = int(time.time())

        tmp = f"{METRICS_FILE}.tmp"
        with open(tmp, "w") as f:
            json.dump(stats, f, indent=2)
        os.replace(tmp, METRICS_FILE)

        self.last_execution_status = "NOMINAL_EXIT"
        log.info("Cycle #%d complete — %d/%d records purified in %.2fms",
                 self.cycle_count, len(purified_dataset), len(raw_mocked_responses),
                 cycle_duration_ms)

    def purge_sensitive_footprint(self) -> None:
        """
        Single-pass overwrite then unlink. Adequate for low-sensitivity cache hygiene;
        NOT a forensic-grade wipe on journaled filesystems — use `shred` for that.
        """
        for target in [LOG_FILE, METRICS_FILE, f"{METRICS_FILE}.tmp"]:
            if os.path.exists(target):
                try:
                    size = os.path.getsize(target)
                    with open(target, "wb") as fh:
                        fh.write(os.urandom(max(size, 1)))
                        fh.flush()
                    os.remove(target)
                except Exception:
                    pass

    async def run_dashboard(self) -> None:
        """
        Owns curses lifecycle inside the running event loop.
        No asyncio.run() nesting — this coroutine IS the top-level task.
        """
        stdscr = curses.initscr()
        curses.noecho()
        curses.cbreak()
        curses.curs_set(0)
        curses.start_color()
        stdscr.nodelay(True)
        stdscr.keypad(True)
        curses.init_pair(1, curses.COLOR_CYAN, curses.COLOR_BLACK)
        curses.init_pair(2, curses.COLOR_RED, curses.COLOR_BLACK)

        try:
            next_run_time = time.time()
            while True:
                h, w = stdscr.getmaxyx()
                stdscr.erase()

                metrics = self.load_metrics()
                logs = self.load_latest_logs(max_lines=h - 15)

                stdscr.attron(curses.color_pair(1) | curses.A_BOLD)
                stdscr.addstr(1, 2, "=" * min(w - 4, 80))
                stdscr.addstr(2, 4, "G.O.D. STACK v2.2.0 | REAL TIME TELEMETRY")
                stdscr.addstr(3, 2, "=" * min(w - 4, 80))
                stdscr.attroff(curses.color_pair(1) | curses.A_BOLD)

                stdscr.addstr(5, 4, f"Sweep Cycles   : {self.cycle_count}")
                stdscr.addstr(6, 4, f"Engine Status  : {self.last_execution_status}")
                stdscr.addstr(7, 4, f"Handled Faults : {self.failures_encountered}")

                stdscr.addstr(5, 44, f"Total Elements : {metrics['tasks_total']}")
                stdscr.addstr(6, 44, f"Pass / Fail    : {metrics['tasks_successful']} / {metrics['tasks_failed']}")
                stdscr.addstr(7, 44, f"Avg Cycle Time : {metrics['avg_latency_ms']:.3f} ms")

                stdscr.addstr(9, 2, "[LOGSTREAM]")
                for idx, line in enumerate(logs):
                    if 10 + idx < h - 4:
                        stdscr.addstr(10 + idx, 4, line.strip()[:w - 8])

                stdscr.attron(curses.color_pair(2) | curses.A_BOLD)
                stdscr.addstr(h - 2, 2, "[ q ] quit and purge")
                stdscr.attroff(curses.color_pair(2) | curses.A_BOLD)
                stdscr.refresh()

                if time.time() >= next_run_time:
                    await self.invoke_pipeline_matrix()
                    next_run_time = time.time() + self.interval

                try:
                    if stdscr.getch() == ord("q"):
                        break
                except Exception:
                    pass

                await asyncio.sleep(0.1)
        finally:
            curses.nocbreak()
            stdscr.keypad(False)
            curses.echo()
            curses.endwin()
            self.purge_sensitive_footprint()


async def _main() -> None:
    orchestrator = RefinedOrchestrator(interval_seconds=300)
    await orchestrator.run_dashboard()


if __name__ == "__main__":
    # asyncio.run() owns the process — curses is initialized inside the coroutine.
    # This eliminates the asyncio.run()-inside-curses.wrapper() nesting entirely.
    try:
        asyncio.run(_main())
    except KeyboardInterrupt:
        pass
