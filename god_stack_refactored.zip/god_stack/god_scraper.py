"""
GodScraper — concurrent URL processor with semaphore-bounded concurrency.

BUG FIXED: Original imported `GodEngineNode` (the now-deleted module-level singleton)
and called `await GodEngineNode.initialize()` / `await GodEngineNode.fetch_and_extract()`.
Engine is now injected at construction time — the same initialized instance shared
across orchestrator, scraper, and worker with no hidden duplicate state.

BUG FIXED: Removed module-level `GodScraperNode = GodScraper()` singleton.

NOTE: `_get_next_targets` dynamic hasattr dispatch is preserved — FrontierManager
exposes `enqueue_batch` and `dequeue` so the primary code paths are always hit,
but the fallback chain is legitimate defensive coding for future frontier variants.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Optional

from god_engine import GodEngine
from frontier_manager import Frontier

log = logging.getLogger("god_stack.scraper")


class GodScraper:
    def __init__(self, engine: GodEngine, concurrency_limit: int = 10) -> None:
        self._engine = engine
        self.concurrency_limit = concurrency_limit
        self.semaphore = asyncio.Semaphore(concurrency_limit)
        self.active = False

    async def initialize(self) -> None:
        log.info("Scraper initializing (concurrency=%d)", self.concurrency_limit)
        self.active = True
        log.info("Scraper active")

    async def process_target(self, url: str) -> None:
        async with self.semaphore:
            if not self.active:
                return
            try:
                result = await self._engine.fetch_and_extract(url)
                if result["status"] == "SUCCESS":
                    links = result["extracted_data"]["links"]
                    if links:
                        log.info("Discovered %d links from %s — enqueuing", len(links), url)
                        if hasattr(Frontier, "enqueue_batch"):
                            Frontier.enqueue_batch(links)
                        elif hasattr(Frontier, "enqueue"):
                            for link in links:
                                Frontier.enqueue(link)
                else:
                    log.warning("Abort state %s for %s", result["status"], url)
            except Exception as exc:
                log.error("Processing failure for %s: %s", url, exc)

    def _get_next_targets(self, batch_size: int = 5) -> list[str]:
        if hasattr(Frontier, "dequeue_batch"):
            return Frontier.dequeue_batch(batch_size=batch_size)

        targets: list[str] = []
        for method_name in ("dequeue", "get", "pop"):
            if hasattr(Frontier, method_name):
                method = getattr(Frontier, method_name)
                for _ in range(batch_size):
                    try:
                        res = method()
                        if res:
                            targets.append(res)
                    except Exception:
                        break
                if targets:
                    return targets
        return targets

    async def start_orchestration_loop(
        self, runtime_limit_ticks: Optional[int] = None
    ) -> None:
        log.info("Entering orchestration loop")
        ticks = 0
        while self.active:
            if runtime_limit_ticks is not None and ticks >= runtime_limit_ticks:
                log.info("Tick limit %d reached — stopping", runtime_limit_ticks)
                break
            next_targets = self._get_next_targets(batch_size=5)
            if not next_targets:
                await asyncio.sleep(0.1)
                ticks += 1
                continue
            await asyncio.gather(
                *[asyncio.create_task(self.process_target(url)) for url in next_targets]
            )
            ticks += 1

    async def shutdown(self) -> None:
        log.info("Scraper shutting down")
        self.active = False
