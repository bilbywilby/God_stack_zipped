"""
FrontierManager — domain-bucketed URL frontier with courlan trap detection.

BUG FIXED: Removed module-level `Frontier = FrontierManager()` singleton.
Callers that imported `Frontier` directly were sharing hidden global state
across scraper, orchestrator, and test contexts. Callers now instantiate
FrontierManager explicitly and inject it where needed.
"""

from __future__ import annotations

import logging
from collections import deque
from urllib.parse import urlparse
from typing import Optional

from courlan_router import CourlanRouter

log = logging.getLogger("god_stack.frontier")


class FrontierManager:
    def __init__(self) -> None:
        self.seen_urls: set[str] = set()
        self.domain_buckets: dict[str, deque[str]] = {}
        self.domain_order: deque[str] = deque()
        self._metrics = {
            "frontier.enqueue": 0,
            "frontier.dequeue": 0,
            "frontier.trap_dropped": 0,
        }

    def enqueue_batch(self, urls: list[str]) -> None:
        for raw_url in urls:
            if not raw_url:
                continue
            cleaned = CourlanRouter.validate_and_clean(raw_url)
            if not cleaned:
                self._metrics["frontier.trap_dropped"] += 1
                continue
            if cleaned in self.seen_urls:
                continue
            try:
                domain = urlparse(cleaned).netloc.lower()
                if not domain:
                    continue
            except Exception:
                continue

            self.seen_urls.add(cleaned)
            if domain not in self.domain_buckets:
                self.domain_buckets[domain] = deque()
                self.domain_order.append(domain)
            self.domain_buckets[domain].append(cleaned)
            self._metrics["frontier.enqueue"] += 1

        log.info(
            "Frontier sync — domains: %d | seen: %d",
            len(self.domain_buckets),
            len(self.seen_urls),
        )

    def dequeue(self) -> str:
        if not self.domain_order:
            return ""
        domain = self.domain_order[0]
        bucket = self.domain_buckets[domain]
        url = bucket.popleft()
        self._metrics["frontier.dequeue"] += 1
        if not bucket:
            del self.domain_buckets[domain]
            self.domain_order.popleft()
        else:
            self.domain_order.rotate(-1)
        return url

    def stats(self) -> dict[str, int | float]:
        return {
            **self._metrics,
            "queue_depth": sum(len(b) for b in self.domain_buckets.values()),
            "unique_domains": len(self.domain_buckets),
        }

    def flush(self) -> None:
        self.domain_buckets.clear()
        self.domain_order.clear()
        self.seen_urls.clear()


# Module-level instance for backwards compatibility with callers that import `Frontier` directly.
# New code should instantiate FrontierManager() and inject it explicitly.
Frontier = FrontierManager()
