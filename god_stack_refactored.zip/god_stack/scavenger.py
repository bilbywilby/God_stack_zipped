"""
ProxyScavenger — harvest and validate public proxy nodes.

BUG FIXED: `if idx := ip.replace('.', '').isdigit():` assigned the boolean result
of `.isdigit()` to `idx` (unused) and used that boolean as the condition — this is
a walrus operator misuse that evaluates correctly by accident (True → append) but
assigns a meaningless name. Replaced with a direct `.isdigit()` check.

BUG FIXED: Removed module-level `logging.basicConfig()` call — it races with all
other modules doing the same. Root config is set once in the process entrypoint.
"""

from __future__ import annotations

import asyncio
import logging

import httpx
from bs4 import BeautifulSoup

log = logging.getLogger("god_stack.scavenger")

_SOURCE_URL = "https://free-proxy-list.net/"
_FALLBACK_PROXY = "http://192.168.1.50:3128"
_VALIDATION_URL = "http://www.google.com"


class ProxyScavenger:
    def __init__(self) -> None:
        self.verified_proxies: list[str] = []

    async def harvest_raw_list(self) -> list[str]:
        log.info("Harvesting proxy list from %s", _SOURCE_URL)
        try:
            async with httpx.AsyncClient(timeout=10.0, follow_redirects=True) as client:
                response = await client.get(_SOURCE_URL)
                response.raise_for_status()

            soup = BeautifulSoup(response.text, "html.parser")
            table = soup.find("table")
            if not table:
                log.warning("No proxy table found in source page")
                return []

            proxies: list[str] = []
            for row in table.find_all("tr")[1:]:
                tds = row.find_all("td")
                if len(tds) >= 2:
                    ip = tds[0].text.strip()
                    port = tds[1].text.strip()
                    # BUG FIX: was `if idx := ip.replace('.', '').isdigit():`
                    # which assigned bool to unused `idx` via walrus operator.
                    if ip.replace(".", "").isdigit():
                        proxies.append(f"http://{ip}:{port}")

            log.info("Harvested %d raw proxy candidates", len(proxies))
            return proxies[:40]

        except Exception as exc:
            log.error("Proxy harvest failed: %s", exc)
            return []

    async def verify_node(self, proxy_url: str) -> None:
        try:
            async with httpx.AsyncClient(
                proxy=proxy_url, timeout=2.5
            ) as client:
                res = await client.get(_VALIDATION_URL)
                if res.status_code == 200:
                    log.info("Verified proxy: %s", proxy_url)
                    self.verified_proxies.append(proxy_url)
        except Exception:
            pass  # Dead node — silently skip

    async def run(self) -> list[str]:
        raw = await self.harvest_raw_list()
        if not raw:
            log.warning("Harvest returned empty — using fallback proxy")
            return [_FALLBACK_PROXY]

        await asyncio.gather(*[self.verify_node(p) for p in raw])
        log.info("Verified %d / %d proxies", len(self.verified_proxies), len(raw))
        return self.verified_proxies if self.verified_proxies else [_FALLBACK_PROXY]


if __name__ == "__main__":
    import logging as _logging
    _logging.basicConfig(level=_logging.INFO, format="%(asctime)s | %(name)s | %(message)s")
    asyncio.run(ProxyScavenger().run())
