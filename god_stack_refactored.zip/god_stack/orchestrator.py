"""
GodOrchestrator — pipeline coordinator: sanitize → proxy → extract.

BUG FIXED: `execute_mission` called `self.engine.process_target_array([clean_url])`
which does not exist on GodEngine. The method has been replaced with the correct
`await self.engine.fetch_and_extract(clean_url)` call.

BUG FIXED: Orchestrator no longer instantiates GodEngine() internally. The engine
is injected at construction time, eliminating the dual-instance state split between
orchestrator.py and god_scraper.py that each owned separate uninitialized engines.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Optional

from god_engine import GodEngine
from url_sanitizer import UrlSanitizer
from scavenger import ProxyScavenger
from captcha_handler import CaptchaHandler

log = logging.getLogger("god_stack.orchestrator")


class GodOrchestrator:
    def __init__(self, engine: GodEngine, use_proxies: bool = False) -> None:
        self._engine = engine
        self._use_proxies = use_proxies
        self._scavenger: Optional[ProxyScavenger] = ProxyScavenger() if use_proxies else None
        self._sentinel = CaptchaHandler()
        self._active_proxies: list[str] = []

    async def initialize_matrix(self) -> None:
        if self._use_proxies and self._scavenger:
            log.info("Bootstrapping proxy egress matrix")
            self._active_proxies = await self._scavenger.run()
        log.info("Orchestrator ready")

    async def execute_mission(self, raw_url: str) -> dict[str, Any]:
        clean_url = UrlSanitizer.normalize(raw_url)
        if not clean_url:
            return {"url": raw_url, "status": "ERROR", "error": "Invalid URL structure",
                    "extracted_data": {"title": None, "body": "", "links": []}}

        log.info("Executing mission: %s", clean_url)
        try:
            result = await self._engine.fetch_and_extract(clean_url)
            return result
        except Exception as exc:
            log.error("Mission failed for %s: %s", clean_url, exc)
            return {"url": clean_url, "status": "ERROR", "error": str(exc),
                    "extracted_data": {"title": None, "body": "", "links": []}}

    async def execute_batch(self, raw_urls: list[str]) -> list[dict[str, Any]]:
        tasks = [self.execute_mission(url) for url in raw_urls]
        return list(await asyncio.gather(*tasks))


if __name__ == "__main__":
    import logging as _logging
    _logging.basicConfig(level=_logging.INFO, format="%(asctime)s | %(name)s | %(message)s")

    async def _cli_test() -> None:
        engine = GodEngine()
        await engine.initialize()
        orchestrator = GodOrchestrator(engine, use_proxies=False)
        await orchestrator.initialize_matrix()
        result = await orchestrator.execute_mission(
            "https://news.ycombinator.com/front?utm_source=test"
        )
        print(result["status"], result.get("extracted_data", {}).get("title"))
        await engine.shutdown()

    asyncio.run(_cli_test())
