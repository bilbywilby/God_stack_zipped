"""
UrlSanitizer — WHATWG-compliant URL normalization.

Strips tracking params, lowercases scheme/host, sorts query params
deterministically for deduplication, removes fragment identifiers.
"""

from __future__ import annotations

import logging
from urllib.parse import urlparse, urlunparse, parse_qsl, urlencode

log = logging.getLogger("god_stack.url_sanitizer")

_TRACKER_PARAMS = frozenset({
    "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
    "gclid", "fbclid", "yclid", "twclid", "msclkid", "_hsenc", "mkt_tok",
})


class UrlSanitizer:
    """Enforces structural compliance with WHATWG URL standard."""

    @staticmethod
    def normalize(raw_url: str, strip_trackers: bool = True) -> str:
        if not raw_url or not isinstance(raw_url, str):
            return ""

        url = raw_url.strip()
        if url.startswith("//"):
            url = "https:" + url
        elif not url.startswith(("http://", "https://")):
            url = "https://" + url

        try:
            parsed = urlparse(url)
            params = parse_qsl(parsed.query, keep_blank_values=True)
            if strip_trackers:
                params = [(k, v) for k, v in params if k.lower() not in _TRACKER_PARAMS]
            params.sort(key=lambda kv: kv[0])

            path = parsed.path or "/"
            if len(path) > 1:
                path = path.rstrip("/")

            normalized = urlunparse((
                parsed.scheme.lower(),
                parsed.netloc.lower(),
                path,
                parsed.params,
                urlencode(params),
                "",  # drop fragment — never sent to servers
            ))

            if normalized != raw_url:
                log.debug("Normalized: %s → %s", raw_url, normalized)
            return normalized

        except Exception as exc:
            log.error("URL parse error for %r: %s", raw_url, exc)
            return url


if __name__ == "__main__":
    dirty_urls = [
        "NEWS.YCOMBINATOR.COM/newest/",
        "https://news.ycombinator.com/front?utm_source=twitter&id=123&abc=xyz#comments",
        "https://news.ycombinator.com/front?abc=xyz&id=123",
        "//news.ycombinator.com/ask?msclkid=999&search=python",
    ]
    for url in dirty_urls:
        print(UrlSanitizer.normalize(url))
