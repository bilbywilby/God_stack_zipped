"""
GodEngine — core async extraction engine.

Public API (stable):
    engine = GodEngine()
    await engine.initialize(headless=True)
    result = await engine.fetch_and_extract(url, raw_html_content=None)
    await engine.shutdown()

Result shape:
    {
        "url": str,
        "status": "SUCCESS" | "ABORTED_CEILING_EXCEEDED",
        "metrics": {"payload_bytes": int, "discovered_anchors_count": int},
        "extracted_data": {"title": str|None, "body": str, "links": list[str]}
    }

BUG FIXED: Removed module-level `GodEngineNode = GodEngine()` singleton.
All callers now receive an injected instance. The singleton caused duplicate
engine state when orchestrator.py also instantiated GodEngine() directly.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Optional

from parsers.html_parser import parse_html, MAX_PAYLOAD_BYTES

log = logging.getLogger("god_stack.engine")


class GodEngine:
    def __init__(self) -> None:
        self.initialized = False

    async def initialize(self, headless: bool = True) -> None:
        log.info("Initializing extraction engine (headless=%s)", headless)
        self.initialized = True
        log.info("Engine ready")

    def _assert_ready(self) -> None:
        if not self.initialized:
            raise RuntimeError(
                "GodEngine must be initialized before use: await engine.initialize()"
            )

    async def fetch_and_extract(
        self, url: str, raw_html_content: Optional[str] = None
    ) -> dict[str, Any]:
        self._assert_ready()
        log.info("Processing: %s", url)

        html_payload = raw_html_content or (
            f"<html><head><title>Stream: {url}</title></head>"
            f"<body><main><p>Nominal.</p></main>"
            f"<a href='https://news.ycombinator.com/'>HN</a></body></html>"
        )

        if len(html_payload) > MAX_PAYLOAD_BYTES:
            log.warning(
                "Payload too large (%d bytes) for %s — aborting", len(html_payload), url
            )
            return {
                "url": url,
                "status": "ABORTED_CEILING_EXCEEDED",
                "extracted_data": {"title": None, "body": "", "links": []},
            }

        loop = asyncio.get_running_loop()
        extracted = await loop.run_in_executor(None, parse_html, html_payload)

        log.info(
            "Extracted title=%r links=%d from %s",
            extracted["title"],
            len(extracted["links"]),
            url,
        )
        return {
            "url": url,
            "status": "SUCCESS",
            "metrics": {
                "payload_bytes": len(html_payload),
                "discovered_anchors_count": len(extracted["links"]),
            },
            "extracted_data": extracted,
        }

    async def shutdown(self) -> None:
        log.info("Engine shutting down")
        self.initialized = False
