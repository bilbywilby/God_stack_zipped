"""
HTML parser — synchronous, safe for asyncio run_in_executor.
Uses selectolax (C-backed) for zero-copy efficiency.
"""

from __future__ import annotations

import re
import logging
from typing import TypedDict

from selectolax.parser import HTMLParser

log = logging.getLogger("god_stack.html_parser")

RE_TITLE_FALLBACK = re.compile(r"<title[^>]*>(.*?)</title>", re.IGNORECASE | re.DOTALL)
RE_CLEAN_WHITESPACE = re.compile(r"\s+")

MAX_PAYLOAD_BYTES = 5_000_000  # 5 MB


class ParsedDocument(TypedDict):
    title: str | None
    body: str
    links: list[str]


def parse_html(raw_html: str) -> ParsedDocument:
    if not raw_html:
        return ParsedDocument(title=None, body="", links=[])

    if len(raw_html) > MAX_PAYLOAD_BYTES:
        log.warning("Payload %d bytes exceeds threshold — dropping", len(raw_html))
        return ParsedDocument(title="Payload Threshold Abort", body="", links=[])

    tree = HTMLParser(raw_html)

    title_node = tree.css_first("title")
    title: str | None = title_node.text().strip() if title_node else None
    if not title:
        match = RE_TITLE_FALLBACK.search(raw_html)
        title = match.group(1).strip() if match else None

    content_nodes = tree.css("article, .post-content, .entry-content, main, p")
    body_text = " ".join(node.text().strip() for node in content_nodes if node.text())
    body = RE_CLEAN_WHITESPACE.sub(" ", body_text).strip()

    links: list[str] = []
    for anchor in tree.css("a[href]"):
        href = anchor.attributes.get("href", "").strip()
        if href and not href.startswith(("javascript:", "mailto:", "#")):
            links.append(href)

    return ParsedDocument(title=title, body=body, links=list(set(links)))
