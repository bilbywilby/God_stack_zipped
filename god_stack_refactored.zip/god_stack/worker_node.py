"""
WorkerNode — async task consumer draining DistributedWorkQueue.

BUG FIXED: Original code caught `KeyboardInterrupt` inside the `while True` loop
of a coroutine. Inside `asyncio.run()`, SIGINT is converted to `CancelledError`
propagated into the running task — a bare `except KeyboardInterrupt` in coroutine
context never fires. The fix: catch `asyncio.CancelledError` explicitly in the
outer coroutine boundary so the `finally` block reliably runs engine.shutdown().

BUG FIXED: Worker no longer owns a GodScraper that re-initializes GodEngine
internally. Engine is injected and shared with the calling process.
"""

from __future__ import annotations

import asyncio
import logging
import uuid

from god_engine import GodEngine
from utils.work_queue import DistributedWorkQueue

log = logging.getLogger("god_stack.worker")


class WorkerNode:
    def __init__(self, engine: GodEngine, poll_interval: float = 5.0) -> None:
        self._engine = engine
        self._queue = DistributedWorkQueue()
        self._poll_interval = poll_interval
        self.worker_id = f"worker-{uuid.uuid4().hex[:6]}"

    async def run(self) -> None:
        log.info("[%s] Online, polling queue", self.worker_id)
        try:
            await self._loop()
        except asyncio.CancelledError:
            # asyncio.run() converts SIGINT → CancelledError on the main task.
            # KeyboardInterrupt never reaches here reliably in coroutine context.
            log.info("[%s] Cancelled — shutting down cleanly", self.worker_id)
        finally:
            await self._engine.shutdown()
            log.info("[%s] Engine released", self.worker_id)

    async def _loop(self) -> None:
        while True:
            task = self._queue.lease_task(self.worker_id)
            if not task:
                log.debug("[%s] Queue empty — sleeping %.1fs", self.worker_id, self._poll_interval)
                await asyncio.sleep(self._poll_interval)
                continue

            task_id, target_url = task
            log.info("[%s] Leased task %s: %s", self.worker_id, task_id, target_url)

            result = await self._engine.fetch_and_extract(target_url)
            if result["status"] == "SUCCESS":
                self._queue.complete_task(task_id)
                log.info("[%s] Completed task %s", self.worker_id, task_id)
            else:
                self._queue.fail_task(task_id)
                log.error(
                    "[%s] Failed task %s: %s",
                    self.worker_id,
                    task_id,
                    result.get("error", result["status"]),
                )
            await asyncio.sleep(2)


async def _main() -> None:
    engine = GodEngine()
    await engine.initialize()
    node = WorkerNode(engine)
    await node.run()


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(name)s | %(message)s",
        datefmt="%H:%M:%S",
    )
    asyncio.run(_main())
