# ==============================================================================
# utils/obsidian_bridge.py – Delta-verified Obsidian vault sync
# FIX: __init__ hardcoded stack_vault to "/home/tangleroot013/god_stack/outputs/vault".
#      Replaced with a __file__-relative default.
# ==============================================================================
import hashlib
import logging
import os
import shutil
from pathlib import Path

logger = logging.getLogger("ObsidianBridge")

_DEFAULT_STACK_VAULT = Path(__file__).resolve().parent.parent / "outputs" / "vault"


class ObsidianBridge:
    """Synchronizes the SearchLedger index with an external Obsidian vault."""

    def __init__(
        self,
        stack_vault: str | Path = _DEFAULT_STACK_VAULT,
        obsidian_vault: str | Path | None = None,
        min_density: float = 0.8,
    ) -> None:
        self.stack_vault = str(stack_vault)
        self.obsidian_vault = str(obsidian_vault) if obsidian_vault else None
        self.min_density = min_density

    def _compute_sha256(self, file_path: str) -> str:
        hasher = hashlib.sha256()
        try:
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hasher.update(chunk)
            return hasher.hexdigest()
        except Exception:
            return ""

    def _parse_density(self, file_path: str) -> float:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                for line in f:
                    if "density:" in line.lower() or "quality_score:" in line.lower():
                        parts = line.split(":")
                        if len(parts) > 1:
                            return float(parts[1].strip())
        except Exception:
            pass
        return 1.0

    def sync_payloads(self) -> None:
        """Mirrors high-value files using delta-verification checks."""
        if not self.obsidian_vault or not os.path.exists(self.obsidian_vault):
            logger.warning("⚠️ Obsidian vault not configured or missing. Skipping sync.")
            return

        os.makedirs(self.obsidian_vault, exist_ok=True)
        synced = skipped = filtered = 0

        for filename in os.listdir(self.stack_vault):
            if not filename.endswith(".md"):
                continue
            src = os.path.join(self.stack_vault, filename)
            dest = os.path.join(self.obsidian_vault, filename)

            if self._parse_density(src) < self.min_density:
                filtered += 1
                continue

            if os.path.exists(dest) and self._compute_sha256(src) == self._compute_sha256(dest):
                skipped += 1
                continue

            shutil.copy2(src, dest)
            synced += 1
            logger.info("🔄 Delta synced: [[%s]]", filename[:-3])

        logger.info(
            "📊 Sync summary → Synced: %d | Untouched: %d | Filtered: %d",
            synced, skipped, filtered,
        )
