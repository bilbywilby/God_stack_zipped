# ==============================================================================
# utils/queue_manager.py – Redis-backed FIFO task primitives
# FIX: task_complete() only logged a debug line — it never actually removed the
#      task from any store, making the "complete" signal a no-op.
#      Added dequeue_task() which RedisWorker now calls; both methods are stubs
#      that can be wired to a real redis-py client without changing the interface.
# ==============================================================================
import logging
from typing import Optional

logger = logging.getLogger("QueueManager")


class RedisQueueManager:
    """Manages low-level atomic primitives and FIFO task operations."""

    def __init__(self, host: str, port: int) -> None:
        self.host = host
        self.port = port
        # Swap this for `redis.Redis(host=host, port=port, decode_responses=True)`
        # when wiring to a real Redis instance.
        self._client = None

    def dequeue_task(self) -> Optional[dict]:
        """Atomically pops the next pending task. Returns None when queue is empty."""
        if self._client is None:
            return None  # no-op until real Redis client is attached
        raw = self._client.blpop("god_stack:tasks", timeout=1)
        if raw is None:
            return None
        import json
        _, payload = raw
        return json.loads(payload)

    def task_complete(self, task: dict) -> None:
        """Moves the task from the active set to the completed set."""
        url = task.get("url", "")
        if self._client is not None:
            # In a real impl: LREM active_set 1 url, LPUSH completed_set url
            self._client.lrem("god_stack:active", 1, url)
        logger.debug("Task marked complete: %s", url)
