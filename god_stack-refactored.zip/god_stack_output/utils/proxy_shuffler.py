# ==============================================================================
# utils/proxy_shuffler.py – Proxy rotation pool and fingerprint spoofing
# FIX: Default proxy_config_path was hardcoded to
#      "/home/tangleroot013/god_stack/config/proxies.json" — breaks on every
#      machine that isn't the author's local box (CI, Docker, other devs).
#      Replaced with a __file__-relative path that works everywhere.
# ==============================================================================
import json
import logging
import random
from pathlib import Path
from typing import Any

log = logging.getLogger("ProxyShuffler")

_DEFAULT_PROXY_CONFIG = Path(__file__).resolve().parent.parent / "config" / "proxies.json"


class ProxyRotationPool:
    """Manages an active array of proxy targets loaded from config specifications."""

    def __init__(self, proxy_config_path: Path | str = _DEFAULT_PROXY_CONFIG) -> None:
        self.config_path = Path(proxy_config_path)
        self.proxies: list[dict[str, Any]] = self._load_pool()

    def _load_pool(self) -> list[dict[str, Any]]:
        if not self.config_path.exists():
            log.warning("Proxy config not found at %s — pool is empty.", self.config_path)
            return []
        try:
            data = json.loads(self.config_path.read_text(encoding="utf-8"))
            return data.get("proxies", [])
        except Exception as exc:
            log.error("Failed to parse proxy pool: %s", exc)
            return []

    def get_isolated_proxy(self) -> dict[str, Any]:
        """Returns a single random proxy configuration from the pool."""
        if not self.proxies:
            return {"host": None, "port": None, "username": None, "password": None}
        return random.choice(self.proxies)


class FingerprintShuffler:
    """Generates realistic client hardware properties to decouple session nodes."""

    _PROFILES: list[dict[str, str]] = [
        {
            "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "vendor": "Intel Inc.",
            "renderer": "Intel Iris Xe Graphics",
        },
        {
            "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15",
            "vendor": "Apple Inc.",
            "renderer": "Apple M2 Engine",
        },
        {
            "user_agent": "Mozilla/5.0 (X11; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0",
            "vendor": "Google Inc.",
            "renderer": "ANGLE (Intel HD Graphics)",
        },
    ]

    def generate_spoofed_profile(self) -> dict[str, str]:
        """Constructs an unlinked client metadata envelope."""
        base = random.choice(self._PROFILES)
        return {
            "user_agent": base["user_agent"],
            "webgl_vendor": base["vendor"],
            "webgl_renderer": base["renderer"],
            "screen_resolution": random.choice(["1920x1080", "1440x900", "2560x1440"]),
        }
