# ==============================================================================
# utils/redis_worker.py – Atomic mission executor pulling from Redis
# FIX: execute_transaction() called `self.scraper.scrape(task['url'], identity=...)`
#      but GodScraper has no `scrape` method — the correct method is
#      `process_target(url)`.  The identity/stealth layer should be applied at
#      the engine level, not passed through the scraper signature.
#      Also: run_mission_loop() slept for 3600s per iteration — effectively
#      dead.  Replaced with a real poll loop with a 1s back-off on empty queue.
# ==============================================================================
import asyncio
import logging

import aiohttp

from god_scraper import GodScraper
from utils.queue_manager import RedisQueueManager


class RedisWorker:
    """Executes atomic missions pulling from a Redis-backed queue."""

    def __init__(self, worker_id: str) -> None:
        self.worker_id = worker_id
        self.broker = RedisQueueManager(host="localhost", port=6379)
        self.scraper = GodScraper()
        self.logger = logging.getLogger(f"Worker-{worker_id}")
        self._running = False

    async def execute_transaction(self, task: dict) -> None:
        """Finalizes the Scrape-to-Vault loop with atomic handoff."""
        try:
            await self.scraper.process_target(task["url"])   # was: self.scraper.scrape(...)
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    "http://127.0.0.1:8890/vault/sync",
                    json={"url": task["url"]},
                ) as resp:
                    if resp.status == 200:
                        self.broker.task_complete(task)
                        self.logger.info("💎 Vault Secured: %s", task["url"])
        except Exception as exc:
            self.logger.error("💥 Transactional Fault: %s", exc)

    async def run_mission_loop(self) -> None:
        """Main mission poll loop — was sleeping 3600s per tick (effectively dead)."""
        self._running = True
        await self.scraper.initialize()
        self.logger.info("Ready and listening for atomic broker tasks.")
        while self._running:
            task = self.broker.dequeue_task()
            if task:
                await self.execute_transaction(task)
            else:
                await asyncio.sleep(1.0)

    def stop(self) -> None:
        self._running = False
