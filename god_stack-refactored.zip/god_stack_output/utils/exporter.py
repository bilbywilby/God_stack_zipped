#!/usr/bin/env python3
# ==============================================================================
# utils/exporter.py – Local SQLite caching layer
# FIX: self.conn held open as an instance variable with no __enter__/__exit__,
#      so any unhandled exception between __init__ and explicit .close() leaks
#      the connection.  Switched to per-call context managers matching the
#      pattern used in data_storage_sync.py.
# ==============================================================================
import logging
import sqlite3
from pathlib import Path

logger = logging.getLogger("Exporter")

_DEFAULT_DB = Path(__file__).resolve().parent.parent / "cache.db"


class DataExporter:
    def __init__(self, db_path: str | Path = _DEFAULT_DB) -> None:
        self.db_path = str(db_path)
        self._init_db()

    def _init_db(self) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("PRAGMA journal_mode=WAL;")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS vault (
                    id        INTEGER PRIMARY KEY AUTOINCREMENT,
                    url       TEXT UNIQUE,
                    payload   TEXT,
                    signature TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)

    def export(self, url: str, payload: str, signature: str) -> None:
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute(
                    "INSERT OR IGNORE INTO vault (url, payload, signature) VALUES (?, ?, ?)",
                    (url, payload, signature),
                )
            logger.info("💾 Cached: %s", url)
        except Exception as exc:
            logger.error("❌ Cache write failed: %s", exc)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(message)s")
    exporter = DataExporter()
    exporter.export("https://example.com", "sample payload", "abc123")
