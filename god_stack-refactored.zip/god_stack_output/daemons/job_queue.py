# ==============================================================================
# daemons/job_queue.py – Centralized SQLite-backed FIFO broker
# FIX 1: Default db_path hardcoded to "/home/tangleroot013/god_stack/outputs/...".
#         Replaced with __file__-relative path.
# FIX 2: pop_task() issued BEGIN IMMEDIATE (exclusive write-lock) even on the
#         SELECT-only path when no task existed, serialising all workers
#         unnecessarily on every empty-queue poll.  Now does a cheap read first,
#         then escalates to IMMEDIATE only when a row actually needs updating.
# ==============================================================================
import logging
import os
import sqlite3
from pathlib import Path

logger = logging.getLogger("DistributedTaskQueue")

_DEFAULT_DB = Path(__file__).resolve().parent.parent / "outputs" / "task_matrix.db"


class DistributedTaskQueue:
    """A centralized FIFO broker for multi-worker synchronization."""

    def __init__(self, db_path: Path | str = _DEFAULT_DB) -> None:
        self.db_path = str(db_path)
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self._initialize_broker()

    def _initialize_broker(self) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("PRAGMA journal_mode=WAL;")
            conn.execute("PRAGMA synchronous=NORMAL;")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS queue (
                    id        INTEGER PRIMARY KEY AUTOINCREMENT,
                    url       TEXT UNIQUE,
                    status    TEXT DEFAULT 'pending',
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)

    def add_target(self, url: str) -> None:
        """Injects a new target into the global task matrix."""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("INSERT INTO queue (url) VALUES (?)", (url,))
        except sqlite3.IntegrityError:
            pass  # already enqueued

    def pop_task(self) -> str | None:
        """Atomically retrieves the next pending task and marks it active."""
        with sqlite3.connect(self.db_path, timeout=30.0) as conn:
            conn.row_factory = sqlite3.Row
            # Cheap read — no lock escalation.
            row = conn.execute(
                "SELECT id, url FROM queue WHERE status = 'pending' LIMIT 1"
            ).fetchone()
            if row is None:
                return None
            # Row found — now take the exclusive lock to update atomically.
            conn.execute("BEGIN IMMEDIATE")
            conn.execute(
                "UPDATE queue SET status = 'active' WHERE id = ?", (row["id"],)
            )
            conn.commit()
            return row["url"]
