#!/usr/bin/env python3
# ==============================================================================
# daemon_core.py – Central heartbeat & long-term scheduler
# ==============================================================================
import asyncio
import logging
from datetime import datetime
from typing import Any, Callable, Coroutine

logger = logging.getLogger("DaemonCore")


class DaemonCore:
    def __init__(self) -> None:
        self.schedules: dict[str, dict] = {}
        # BUG FIX: last_run was None, causing `now - self.last_run` to raise
        # TypeError on the very first iteration of run_forever before any job ran.
        # Fix: initialise to a datetime guaranteed to fire all jobs immediately.
        self._last_run_per_job: dict[str, datetime] = {}

    async def register_job(
        self,
        name: str,
        interval: int,
        coro: Callable[[], Coroutine[Any, Any, Any]],
    ) -> None:
        self.schedules[name] = {"interval": interval, "coro": coro}
        # Seed last_run to epoch so the job fires on the first tick.
        self._last_run_per_job[name] = datetime.min
        logger.info("Registered job: %s every %ds", name, interval)

    async def run_forever(self) -> None:
        while True:
            now = datetime.now()
            for name, cfg in self.schedules.items():
                elapsed = (now - self._last_run_per_job[name]).total_seconds()
                if elapsed >= cfg["interval"]:
                    logger.info("🔄 Executing scheduled job: %s", name)
                    try:
                        await cfg["coro"]()
                    except Exception as exc:
                        logger.error("Job %s raised: %s", name, exc)
                    self._last_run_per_job[name] = now
            await asyncio.sleep(1)


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | [DAEMON-CORE] %(message)s",
        datefmt="%H:%M:%S",
    )

    async def _demo() -> None:
        core = DaemonCore()

        async def heartbeat() -> None:
            logger.info("heartbeat fired")

        await core.register_job("heartbeat", 5, heartbeat)
        await core.run_forever()

    asyncio.run(_demo())
