#!/usr/bin/env python3
# ==============================================================================
# parsers/content_extractor.py – Structural content normalization
# FIX: Original used a brittle string-match heuristic (`is_mock = "Standard
#      Source Tree" in raw_html`) to decide whether to parse or substitute a
#      placeholder.  This silently discards real content if the string happens
#      to appear, and does zero real extraction for all other inputs.
#      Replaced with the actual parse_html() pipeline already in this codebase.
# ==============================================================================
import json
import logging
from datetime import datetime, timezone

from parsers.html_parser import parse_html

logger = logging.getLogger("ContentExtractor")


class ContentExtractor:
    """FOSS-compliant structural text and metadata extraction utility."""

    @staticmethod
    def extract_payload(raw_html: str, source_url: str) -> dict:
        """Parses raw HTML into a normalized storage record."""
        logger.info("🧬 Extracting from: %s", source_url)

        parsed = parse_html(raw_html, base_url=source_url)

        title = parsed["title"] or source_url
        body = parsed["body"] or raw_html

        return {
            "title": title,
            "source_url": source_url,
            "extracted_at": datetime.now(timezone.utc).isoformat(),
            "content_length": len(body),
            "payload_data": body,
            "links_discovered": len(parsed["links"]),
            "status": "PROCESSED",
        }


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(message)s")
    sample = "<html><body><h1>Diagnostic Feed</h1><p>Active FOSS tokens.</p></body></html>"
    record = ContentExtractor.extract_payload(sample, "https://example.com/feed")
    print(json.dumps(record, indent=2))
