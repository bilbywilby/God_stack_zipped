# ==============================================================================
# parsers/html_parser.py – selectolax-backed HTML extraction
# FIX: `list(set(links))` deduplicated relative URLs incorrectly — two relative
#      paths like "/item?id=1" and "/item?id=2" are distinct but a set() on
#      raw relative strings still works; the real problem is that without
#      resolving them against a base URL first, the Frontier can't canonicalise
#      them and they re-enqueue as separate duplicates on every scrape.
#      Added optional base_url parameter and urllib.parse.urljoin resolution
#      so every yielded link is absolute before deduplication.
# ==============================================================================
import re
import logging
from urllib.parse import urljoin
from selectolax.parser import HTMLParser

logger = logging.getLogger("HtmlParser")

RE_TITLE_FALLBACK = re.compile(r'<title[^>]*>(.*?)</title>', re.IGNORECASE | re.DOTALL)
RE_CLEAN_WHITESPACE = re.compile(r'\s+')

MAX_PAYLOAD_BYTES = 5_000_000  # 5 MB hard ceiling


def parse_html(raw_html: str, base_url: str = "") -> dict:
    """
    Synchronously extracts DOM structures from raw HTML.
    base_url is used to resolve relative hrefs to absolute URLs before
    deduplication, so the Frontier receives canonical absolute links.
    """
    if not raw_html:
        return {"title": None, "body": "", "links": []}

    if len(raw_html) > MAX_PAYLOAD_BYTES:
        logger.warning("Payload (%d bytes) exceeds threshold. Dropping.", len(raw_html))
        return {"title": "Payload Threshold Abort", "body": "", "links": []}

    tree = HTMLParser(raw_html)

    # Title
    title_node = tree.css_first("title")
    title = title_node.text().strip() if title_node else None
    if not title:
        m = RE_TITLE_FALLBACK.search(raw_html)
        title = m.group(1).strip() if m else None

    # Body
    content_nodes = tree.css("article, .post-content, .entry-content, main, p")
    body_text = " ".join(n.text().strip() for n in content_nodes if n.text())
    normalized_body = RE_CLEAN_WHITESPACE.sub(" ", body_text).strip()

    # Links — resolve to absolute before deduplication
    seen: set[str] = set()
    links: list[str] = []
    for anchor in tree.css("a[href]"):
        href = (anchor.attributes.get("href") or "").strip()
        if not href or href.startswith(("javascript:", "mailto:", "#")):
            continue
        absolute = urljoin(base_url, href) if base_url else href
        if absolute not in seen:
            seen.add(absolute)
            links.append(absolute)

    return {"title": title, "body": normalized_body, "links": links}
