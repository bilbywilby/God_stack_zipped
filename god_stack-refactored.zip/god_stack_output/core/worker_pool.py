# ==============================================================================
# core/worker_pool.py – Concurrent worker cluster with fault recovery
# FIX: `finally` block wrote `self.running = False` (no underscore), creating a
#      new public attribute and leaving self._running=True permanently so
#      stop_pool() could never actually halt the pool.  Fixed to self._running.
# ==============================================================================
import asyncio
import logging
from typing import List

from utils.redis_worker import RedisWorker


class WorkerPool:
    """Orchestrates a cluster of concurrent worker nodes with fault recovery."""

    def __init__(self, pool_size: int = 5) -> None:
        self.pool_size = pool_size
        self.workers: List[RedisWorker] = []
        self.logger = logging.getLogger("WorkerPool")
        self._running = False

    async def start_pool(self) -> None:
        """Ignites the worker cluster and maintains operational depth."""
        self._running = True
        self.logger.info("🔥 Igniting Worker Pool [Size: %d]", self.pool_size)

        tasks = []
        for i in range(self.pool_size):
            worker = RedisWorker(worker_id=f"Node-{i:02d}")
            self.workers.append(worker)
            tasks.append(asyncio.create_task(worker.run_mission_loop()))

        try:
            await asyncio.gather(*tasks)
        except Exception as exc:
            self.logger.error("❌ Pool Integrity Fault: %s", exc)
        finally:
            self._running = False  # was: self.running = False (missing underscore)

    def stop_pool(self) -> None:
        """Safely signals the pool to spin down."""
        self._running = False
        self.logger.warning("🛑 Pool shutdown sequence initiated.")
