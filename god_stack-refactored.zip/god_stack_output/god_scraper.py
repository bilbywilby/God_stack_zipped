# ==============================================================================
# god_scraper.py – Async scraping orchestrator with semaphore-bounded concurrency
# FIX 1: Module-level `GodScraperNode = GodScraper()` created asyncio.Semaphore
#         at import time, before any event loop exists — raises DeprecationWarning
#         in 3.10 and RuntimeError in 3.12+.  Semaphore now created lazily inside
#         initialize() which is always called from within a running loop.
# FIX 2: redis_worker.py called `self.scraper.scrape(...)` but the method is
#         named `process_target`.  Corrected the call-site comment; the actual
#         fix lives in redis_worker.py.
# ==============================================================================
import asyncio
import logging
from typing import List, Optional

from frontier_manager import Frontier
from god_engine import GodEngineNode

logger = logging.getLogger("GodScraper")


class GodScraper:
    def __init__(self, concurrency_limit: int = 10) -> None:
        self.concurrency_limit = concurrency_limit
        self._semaphore: Optional[asyncio.Semaphore] = None   # created in initialize()
        self.active = False

    async def initialize(self) -> None:
        """Prepares worker matrices and underlying extraction dependencies."""
        # Semaphore created here — guaranteed to be inside a running event loop.
        self._semaphore = asyncio.Semaphore(self.concurrency_limit)
        logger.info("Initializing unified scraping engine runner sequence...")
        await GodEngineNode.initialize(headless=True)
        self.active = True
        logger.info("Scraper active. Concurrency ceiling: %d", self.concurrency_limit)

    async def process_target(self, url: str) -> None:
        """Handles an isolated route extraction cycle with structural rate bounds."""
        assert self._semaphore is not None, "Call initialize() before process_target()"
        async with self._semaphore:
            if not self.active:
                return
            try:
                result = await GodEngineNode.fetch_and_extract(url)
                if result["status"] == "SUCCESS":
                    discovered_links = result["extracted_data"]["links"]
                    if discovered_links:
                        logger.info(
                            "Discovered %d outbound routes from %s. Enqueuing...",
                            len(discovered_links), url,
                        )
                        Frontier.enqueue_batch(discovered_links)
                else:
                    logger.warning("Abort state %s for %s", result["status"], url)
            except Exception as exc:
                logger.error("Processing fault on %s: %s", url, exc)

    def _get_next_targets(self, batch_size: int = 5) -> List[str]:
        """Drains up to batch_size URLs from the Frontier."""
        targets: List[str] = []
        for _ in range(batch_size):
            url = Frontier.dequeue()
            if url:
                targets.append(url)
            else:
                break
        return targets

    async def start_orchestration_loop(self, runtime_limit_ticks: Optional[int] = None) -> None:
        """Continually drains the Frontier until teardown."""
        logger.info("Entering operational extraction matrix runloop...")
        ticks = 0
        while self.active:
            if runtime_limit_ticks and ticks >= runtime_limit_ticks:
                logger.info("Tick threshold surpassed. Stopping runloop.")
                break
            next_targets = self._get_next_targets(batch_size=5)
            if not next_targets:
                await asyncio.sleep(0.1)
                ticks += 1
                continue
            await asyncio.gather(*[
                asyncio.create_task(self.process_target(url)) for url in next_targets
            ])
            ticks += 1

    async def shutdown(self) -> None:
        """Terminates engine tasks and cleans workspace pipeline states."""
        logger.info("Executing graceful scraper teardown sequence...")
        self.active = False
        await GodEngineNode.shutdown()
        logger.info("Scraper core subsystem deactivated successfully.")


# NOTE: No module-level singleton instantiation here.  Callers that need a
# shared instance should create one inside their own async entry point after
# the event loop is running, then await .initialize().
